"""Local operator HTTP interface."""
