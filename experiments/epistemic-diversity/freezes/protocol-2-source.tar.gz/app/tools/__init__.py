"""Validated tool capabilities."""
