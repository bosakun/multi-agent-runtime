"""Provider-independent model calls."""
