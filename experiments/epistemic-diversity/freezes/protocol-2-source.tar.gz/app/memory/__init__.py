"""Explicitly scoped memory interfaces."""
