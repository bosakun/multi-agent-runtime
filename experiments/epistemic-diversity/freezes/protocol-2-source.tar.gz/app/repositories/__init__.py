"""Transactional storage adapters."""
