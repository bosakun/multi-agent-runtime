"""CLI module entrypoint."""
